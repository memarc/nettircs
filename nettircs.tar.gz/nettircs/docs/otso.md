# YksinOtso

![plotso](/media/profile.png)

I am Otso, currently the only one developing software here. In other
words, I am
"[Yksin](https://www.sanakirja.org/search.php?q=yksin&l=17&l2=3) [Otso](https://www.sanakirja.org/search.php?q=otso&l=17&l2=3)."
\
\

