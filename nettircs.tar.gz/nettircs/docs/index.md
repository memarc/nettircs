# Welcome to NettiRCS

Jealous of all the attractive git web clients but not jealous of git's
relative complexity to [rcs(1)](http://man.openbsd.org/rcs), I decided to
create *Netti*RCS to allow me to display my projects, and their version
controls without needing to host a full-blown git server and without
needing to deal with git ([Why not git?](https://yksinotso.org/cgi-bin/yksinotso/musings?sub=whynotgit)).

It still need a lot more research, and a lot more work.

### Possible Features
-Revision Exploration\
\-Vieing different versions of files in the browser.
\-Viewing and downloading the project as it was committed at a certain
date in the browser
-Accounts
\-Accounts would have the ability to create new directories, and be
given some way to commit to them.\
\-Currently, the only options are making the RCS directories permission
\6\6\6 or to make users run as www to put files in them and make
permissions 644.\
Ideally, I could do some sort of file upload and use .htpasswd or
something.

### What this isn't
-Git
\-This is designed to be a simple interface to show RCS revisions. It
should not try to replace git as a large project, many contributor
distributed system. Basically, don't try to do anything RCS can't easily
be made to do.

-Editor
\-I use [vi(1)](http://man.openbsd.org/vi). To make a web interface as
quick and feature rich as *vi* without introducing a bunch of bugs is
not what I want to spend my time doing. This is for displaying and
exploring RCS files, nothing more.
\
\

